package com.goprocessing.gowallet;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class Transfer extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_transfer );
        Toast.makeText( Transfer.this,"Transfer",Toast.LENGTH_LONG ).show();
    }
}
